/**
 * The gateway (reference 3): a painted gopuram stands at the end of the courtyard.
 * As you scroll, the camera walks up to it and through the lit doorway — the
 * invitation waits inside. Scroll progress (--p) comes from <Cinema/>.
 */
import s from "./scene.module.css";
import { Gopuram } from "@/components/art/Temple";
import { Kolam } from "@/components/art/Ornate";

export default function Gateway() {
  return (
    <section className={s.gateway} id="gateway" data-scene="gateway" aria-label="The temple gateway">
      <div className={s.sticky}>
        <div className={s.sky} />
        <div className={s.sun} />
        <div className={s.gopuramWrap}>
          <Gopuram className={s.gopuram} />
        </div>
        <div className={s.gateFloor}>
          <Kolam className={s.floorKolam} n={5} />
        </div>
        <div className={s.gateText}>
          <p className={s.kicker}>Step inside</p>
          <p className={s.gateLine}>Through the temple gate, our families welcome you.</p>
        </div>
        <div className={s.doorLight} aria-hidden="true" />
      </div>
    </section>
  );
}
