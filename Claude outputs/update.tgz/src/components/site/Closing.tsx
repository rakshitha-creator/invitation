/**
 * Closing (reference 9): beneath a gold arch hung with marigolds and bells, Sita's
 * mehendi hand and Ram's blue hand drift together as you scroll until their little
 * fingers link. Scroll progress (--p) comes from <Cinema/>.
 */
import type { CSSProperties } from "react";
import s from "./scene.module.css";
import { GarlandArch } from "@/components/art/Ornate";
import { Foliage } from "@/components/art/Nature";
import { Hand } from "@/components/art/People";
import Petals from "./Petals";
import { wedding } from "@/content/wedding";

export default function Closing() {
  const { bride, groom } = wedding;
  return (
    <footer className={s.closing} id="closing" data-scene="closing">
      <GarlandArch className={s.closingArch} />
      <Petals count={16} />
      <div className={s.hands} aria-hidden="true">
        <Hand who="sita" className={s.handSita} />
        <Hand who="ram" className={s.handRam} />
      </div>
      <div className={s.closingText}>
        <p className={s.closingBlessing} data-reveal="up">
          {wedding.final.blessing}
        </p>
        <p className={s.closingNames} data-reveal="tilt" style={{ "--d": 1 } as CSSProperties}>
          {bride} <em>&amp;</em> {groom}
        </p>
        <p className={s.closingDate} data-reveal="up" style={{ "--d": 2 } as CSSProperties}>
          {wedding.date.long} · {wedding.place.city}
        </p>
        <p className={s.closingLine} data-reveal="up" style={{ "--d": 3 } as CSSProperties}>
          {wedding.final.line}
        </p>
        <p className={s.closingThanks} data-reveal="up" style={{ "--d": 4 } as CSSProperties}>
          {wedding.final.thanks}
        </p>
      </div>
      <Foliage className={s.foliage} />
    </footer>
  );
}
