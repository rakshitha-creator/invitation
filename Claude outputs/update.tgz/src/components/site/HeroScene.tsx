/**
 * Hero — reference 2 rebuilt as a layered 3D scene.
 *
 * Every object from the reference sits on its own depth plane inside a CSS
 * `perspective` stage (true translateZ, size-compensated so the composition matches
 * the reference at rest):
 *
 *   far   watercolour wash ·· hanging bells ·· banana leaves ·· carved pillar
 *   mid   names + date
 *   near  the couple · brass elephant · kuthuvilakku + kalash · lotus pond
 *
 * <Cinema/> then moves the camera: pointer/drift parallax, and on scroll a slow dolly
 * *into* the scene (near layers sweep past, far layers barely move).
 */
import type { CSSProperties } from "react";
import s from "./scene.module.css";
import { Bell, Elephant, Kalash, Lamp, Pillar } from "@/components/art/Temple";
import { BananaLeaves, LotusPond } from "@/components/art/Nature";
import { CoupleBack } from "@/components/art/People";
import Petals from "./Petals";
import { wedding } from "@/content/wedding";

const z = (depth: number, i: number) => ({ "--z": depth, "--i": i }) as CSSProperties;

export default function HeroScene() {
  const { bride, groom } = wedding;
  return (
    <section className={s.hero} id="top" data-scene="hero" aria-labelledby="hero-names">
      <div className={s.sticky}>
        <div className={s.stage}>
          <div className={s.world}>
            <div className={`${s.layer} ${s.wash}`} style={z(-700, 0)} />

            <div className={`${s.layer} ${s.bells}`} style={z(-260, 1)}>
              <Bell className={`${s.bell} swing`} chain={120} style={{ animationDelay: "0s" }} />
              <Bell className={`${s.bell} swing`} chain={190} style={{ animationDelay: "-1.4s" }} />
              <Bell className={`${s.bell} swing`} chain={150} style={{ animationDelay: "-2.6s" }} />
            </div>

            <div className={`${s.layer} ${s.leaves}`} style={z(-200, 2)}>
              <BananaLeaves flip className={s.leavesArt} />
            </div>

            <div className={`${s.layer} ${s.pillar}`} style={z(-140, 2)}>
              <Pillar className={s.pillarArt} />
            </div>

            <div className={`${s.layer} ${s.copy}`} style={z(-60, 3)}>
              <p className={s.kicker}>The wedding of</p>
              <h1 className={s.names} id="hero-names">
                <span>{bride}</span>
                <em>&amp;</em>
                <span>{groom}</span>
              </h1>
              <p className={s.when}>
                <span>{wedding.date.long}</span>
                <span aria-hidden="true">·</span>
                <span>
                  {wedding.place.city}, {wedding.place.region}
                </span>
              </p>
              <p className={s.subtitle}>{wedding.hero.subtitle}</p>
              <a href="#gateway" className={s.cue}>
                <span>Scroll to enter</span>
                <i aria-hidden="true" />
              </a>
            </div>

            <div className={`${s.layer} ${s.couple}`} style={z(30, 4)}>
              <CoupleBack className={s.coupleArt} />
            </div>

            <div className={`${s.layer} ${s.elephant}`} style={z(70, 5)}>
              <Elephant className={s.elephantArt} />
            </div>

            <div className={`${s.layer} ${s.lamp}`} style={z(90, 5)}>
              <Lamp className={s.lampArt} />
              <Kalash className={s.kalashArt} />
            </div>

            <div className={`${s.layer} ${s.lotus}`} style={z(170, 6)}>
              <LotusPond className={s.lotusArt} />
            </div>
          </div>
        </div>

        <Petals count={20} />
        <div className={s.heroFade} aria-hidden="true" />

      </div>
    </section>
  );
}
