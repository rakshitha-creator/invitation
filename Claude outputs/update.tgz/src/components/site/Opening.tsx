"use client";
/**
 * Cinematic opening (reference 1, recreated in code):
 *   floral gold border → scalloped Mughal arch on maroon damask → a parchment scroll
 *   unrolls → "Finally it's happening! We are getting married soon…" writes on →
 *   the scroll rolls away → "Sita weds Ram", the date and the city appear →
 *   "Open Our Wedding Invitation" → the camera pushes through the arch into the hero.
 *
 * - ~8 s long, skippable at any moment (Skip button, Esc).
 * - If `wedding.opening.video` is set, that video plays full-screen (muted, inline,
 *   with poster) and the names are layered over it instead.
 * - Reduced motion → the finished frame is shown at once.
 * - No JS → hidden by CSS, so the page is never blocked.
 */
import { useCallback, useEffect, useRef, useState, type CSSProperties } from "react";
import styles from "./opening.module.css";
import { FloralBorder, MughalArch } from "@/components/art/Ornate";
import { Lamp } from "@/components/art/Temple";
import Petals from "./Petals";
import { wedding } from "@/content/wedding";

/** stage: 0 arch · 1 unroll · 2 write · 3 roll up · 4 names · 5 ready · 6 leaving · 7 gone */
const TIMELINE = [0, 1100, 2500, 6300, 7200, 8400];

export default function Opening() {
  const [stage, setStage] = useState(0);
  const [videoFailed, setVideoFailed] = useState(false);
  const timers = useRef<number[]>([]);
  const enterRef = useRef<HTMLButtonElement>(null);
  const video = wedding.opening.video && !videoFailed ? wedding.opening.video : null;
  const { bride, groom } = wedding;

  const clear = () => {
    timers.current.forEach(clearTimeout);
    timers.current = [];
  };

  const finish = useCallback(() => {
    clear();
    setStage((s) => (s < 5 ? 5 : s));
  }, []);

  const enter = useCallback(() => {
    clear();
    setStage(6);
    const root = document.documentElement;
    root.dataset.entered = "";
    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    timers.current.push(
      window.setTimeout(() => {
        setStage(7);
        root.style.removeProperty("overflow");
        window.dispatchEvent(new Event("opening:done"));
      }, reduce ? 50 : 1300),
    );
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    // deep links (e.g. /#events) skip straight in
    if (location.hash) {
      root.dataset.entered = "";
      setStage(7);
      window.dispatchEvent(new Event("opening:done"));
      return;
    }
    root.style.overflow = "hidden";
    if (matchMedia("(prefers-reduced-motion: reduce)").matches) {
      setStage(5);
    } else if (video) {
      timers.current.push(window.setTimeout(() => setStage(4), 1400), window.setTimeout(() => setStage(5), 2600));
    } else {
      TIMELINE.forEach((t, i) => i && timers.current.push(window.setTimeout(() => setStage(i), t)));
    }
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") finish();
    };
    addEventListener("keydown", onKey);
    return () => {
      clear();
      removeEventListener("keydown", onKey);
      root.style.removeProperty("overflow");
    };
  }, [finish, video]);

  useEffect(() => {
    if (stage === 5) enterRef.current?.focus({ preventScroll: true });
  }, [stage]);

  if (stage === 7) return null;

  const d = (i: number) => ({ "--i": i }) as CSSProperties;

  return (
    <div
      className={styles.opening}
      data-stage={stage}
      data-video={video ? "" : undefined}
      role="dialog"
      aria-modal="true"
      aria-label={`Wedding invitation of ${bride} and ${groom}`}
    >
      {video ? (
        <video
          className={styles.video}
          src={video}
          poster={wedding.opening.poster ?? undefined}
          autoPlay
          muted
          playsInline
          preload="auto"
          onError={() => setVideoFailed(true)}
        />
      ) : (
        <FloralBorder className={styles.border} />
      )}

      <div className={styles.stage}>
        <div className={styles.archBox}>
          {!video && <MughalArch className={styles.arch} />}
          {stage >= 4 && <Petals count={22} />}

          <div className={styles.content}>
            <p className={styles.blessing} lang="sa">
              {wedding.invitation.blessing}
            </p>
            <p className={styles.together}>{wedding.opening.together}</p>

            {!video && (
              <div className={styles.scroll} aria-hidden={stage < 2 || stage > 3}>
                <span className={`${styles.roller} ${styles.rollerTop}`} />
                <div className={styles.paper}>
                  <p className={styles.script}>
                    {wedding.opening.scroll.map((line, i) => (
                      <span key={line} style={d(i)}>
                        {line}
                      </span>
                    ))}
                  </p>
                </div>
                <span className={`${styles.roller} ${styles.rollerBottom}`} />
              </div>
            )}

            <div className={styles.finale}>
            <p className={styles.names}>
              <span style={d(0)}>{bride}</span>
              <em style={d(1)}>&amp;</em>
              <span style={d(2)}>{groom}</span>
            </p>
            <p className={styles.date} style={d(3)}>
              {wedding.date.long.replace(/^\w+, /, "")}
            </p>
            <p className={styles.place} style={d(4)}>
              {wedding.place.city}
            </p>
            </div>
          </div>

          {!video && (
            <>
              <Lamp className={`${styles.lamp} ${styles.lampL}`} />
              <Lamp className={`${styles.lamp} ${styles.lampR}`} />
            </>
          )}
        </div>

        <button ref={enterRef} type="button" className={styles.enter} onClick={enter} tabIndex={stage >= 5 ? 0 : -1}>
          <span>{wedding.opening.button}</span>
        </button>
      </div>

      {stage < 5 && (
        <button type="button" className={styles.skip} onClick={finish}>
          Skip intro
        </button>
      )}
    </div>
  );
}
