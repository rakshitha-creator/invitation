# Sita ♥ Ram — wedding invitation

Next.js 15 · React 19 · TypeScript · CSS Modules

```bash
npm install
npm run dev            # http://localhost:3000
npm run build && npm start
```

## The experience
A cinematic South Indian wedding invitation, built from the 10 Pinterest references
(see **REFERENCES.md** for the reference → section map). All artwork is original SVG
drawn in code (`src/components/art/`), layered in real CSS 3D depth.

1. **Opening** (`Opening.tsx`, ref 1): gold floral border, scalloped arch on maroon damask, a parchment
   scroll unrolls with "Finally it's happening! We are getting married soon…", then *Sita & Ram*,
   1 January 2027, Anantapur and **Open Our Wedding Invitation**. Skippable (button or Esc), ~8 s.
   Optional licensed video: see `public/video/README.txt`.
2. **Hero** (`HeroScene.tsx`, ref 2): bells, banana leaves, carved pillar, the couple seen from behind,
   brass elephant, lit kuthuvilakku, kalash and lotus pond on nine depth planes. The pointer (or a slow
   drift on phones) moves the camera; scrolling dollies *into* the scene.
3. **Gateway** (`Gateway.tsx`, ref 3): you walk up to a painted gopuram and through its lit doorway.
4. **Invitation** (`InviteCard.tsx`, refs 4 + 9): a two-leaf card between carved peacock pillars under a
   marigold-and-bell arch. Tap the silk cover and it swings open in 3D.
5. **The Bride & Groom** (ref 7): portraits in a courtyard of banana trees, brass lamps and a floor kolam.
6. **Our Story** (ref 8): the saptapadi: feet, hems and the tied knot, then footprints walking a path
   that draws itself as you scroll.
7. **Celebrations** (refs 6 + 10): maroon with a self-drawing kolam, jasmine bells, a lamp and urli. Each
   event card opens on its own painted scene and time of day.
8. **Venue** (ref 5): banana trees in gold pots and garlanded pillars, Directions + Add to calendar.
9. **Gallery**, **Countdown**, **RSVP + Instagram**.
10. **Closing** (ref 9): Sita's mehendi hand and Ram's blue hand drift together as you scroll.

Motion: `Cinema.tsx` (GSAP ScrollTrigger: hero dolly, gateway walk, story path, hands), `Motion.tsx`
(reveals, parallax, tilt), `Petals.tsx` (light canvas petals). With *reduced motion* everything is shown
at rest, with no tall scroll stages. Without JavaScript the opening is hidden and every section shows.

## Change the content: `src/content/wedding.ts`
Names, every line of text, parents' names, the events, RSVP phone/WhatsApp, Instagram, the countdown date and music.
- **Events:** `date`, `time`, `venue`, `location` and `mapsUrl` are `null`, so they show "To be announced". Nothing was invented. A Directions button appears once `mapsUrl` is set. `photo` picks the card image.
- **Parents:** set `parents.bride` / `parents.groom`, and a "daughter of … / son of …" line appears.
- **Date & place:** `date` (wedding day, set to 1 January 2027; set `date.iso` to the muhurat time and
  `timeConfirmed: true` once known) and `place` (Anantapur; add `venue`, `address`, `mapsUrl`).
- **Opening:** `opening.scroll` lines, button text, optional `video` / `poster`.
- **Music:** put a track you are licensed to use in `public/audio/` and set `music.src`. Until then, a quiet original ambience is synthesised in the browser.

## Replace the photos
- **Wedding photos:** in `public/images/wedding/`, keep the **same file names**:
  `bride.jpg  groom.jpg  couple-01.jpg  couple-02.jpg  couple-03.jpg  pre-wedding.jpg
  family.jpg  ceremony.jpg  rings.jpg  temple.jpg  mandap.jpg  mehendi.jpg`.
  Next.js serves them as AVIF or WebP automatically. If a photo's shape changes a lot, update `width`/`height` in `src/content/photos.ts`.
- **Temple photos:** in `public/images/site/`, the files are `hero-tall.jpg`, `hero-wide.jpg`, `pillars.jpg` and `gopuram-dusk.jpg`.
- The current photos are temporary Unsplash images (see `ASSET-CREDITS.md`).

## Structure
```
src/app/                 layout (fonts, metadata), globals.css (colours, fonts), page
src/content/             wedding.ts (all text/data), photos.ts (photo manifest)
src/components/art/      original SVG artwork (temple objects, plants, couple, kolam, arches, event scenes)
src/components/site/     Opening, HeroScene, Gateway, InviteCard, Closing, Cinema (GSAP scroll camera),
                         Petals, scene.module.css, opening.module.css, Invitation (all sections), Events (cards), Countdown, Music,
                         Motion (scroll reveals, parallax, tilt), Ornament (SVG divider + kalash),
                         site.module.css (all styles)
src/lib/ambient.ts       synthesised music
```
Files in the older folders (`components/experience`, `components/scenes`, `three`, `journey`)
are empty placeholders left from the previous version and can be deleted, along with
`public/images/temple/`. `gsap` is used again (Cinema.tsx); `three` is still unused.

## Accessibility
- Event cards, arrows and dots work by keyboard and touch. Links and buttons are at least 46 px tall.
- With `prefers-reduced-motion`, all animation, parallax, tilt and smooth scrolling is turned off and everything shows at once.
- If JavaScript is off, every section is still visible (the hidden "before" state only applies once motion is switched on).
