# Sita ♥ Ram — wedding invitation

Next.js 15 · React 19 · TypeScript · CSS Modules

```bash
npm install
npm run dev            # http://localhost:3000
npm run build && npm start
```

## The page
A clean, bright invitation that scrolls normally, one section after another. It uses sharp
photographs, solid ivory and maroon backgrounds and thin gold lines.

**Motion (3D, no blur):**
- The hero photo settles in with a slow zoom, and each letter of the names turns up into place in 3D.
- As you scroll, photos and text move at different depths (parallax), and a thin gold progress line runs across the top.
- Each section enters in 3D. Titles flip up, the arch card swings forward, the portraits and story photos turn in from the sides, event cards and gallery photos rise up, and the countdown tiles flip.
- With a mouse, cards and photos tilt toward the pointer and catch a soft highlight.
- The kalash ornaments sway, and the WhatsApp button has a gold shine.

All of this lives in `src/components/site/Motion.tsx` (no libraries) and the `data-reveal`
styles in `globals.css`. It turns off automatically for guests who prefer reduced motion.

1. **Hero:** the names beside a colourful temple tower. On phones, the names sit over a temple in daylight.
2. **Invitation:** an arch-shaped card (॥ श्री गणेशाय नमः ॥) over a pillared temple hall.
3. **The Bride & Groom:** two arch-framed portraits.
4. **Our Story:** four moments with photos.
5. **The Celebrations:** Haldi, Mehendi, Sangeet, Wedding and Reception. On phones these are swipeable cards with arrows; on desktop they show as a grid.
6. **Moments:** a photo gallery.
7. **Counting the Days:** a countdown to the muhurat.
8. **RSVP and Instagram:** an RSVP on WhatsApp button, Call / WhatsApp 9347915212, and @cine__snaps__.
9. **Thank you:** a temple at dusk.

A small round button (bottom right) plays music. Nothing autoplays.

## Change the content: `src/content/wedding.ts`
Names, every line of text, parents' names, the events, RSVP phone/WhatsApp, Instagram, the countdown date and music.
- **Events:** `date`, `time`, `venue`, `location` and `mapsUrl` are `null`, so they show "To be announced". Nothing was invented. A Directions button appears once `mapsUrl` is set. `photo` picks the card image.
- **Parents:** set `parents.bride` / `parents.groom`, and a "daughter of … / son of …" line appears.
- **Countdown:** set `weddingDateTime`, e.g. `"2026-12-12T10:30:00+05:30"`.
- **Music:** put a track you are licensed to use in `public/audio/` and set `music.src`. Until then, a quiet original ambience is synthesised in the browser.

## Replace the photos
- **Wedding photos:** in `public/images/wedding/`, keep the **same file names**:
  `bride.jpg  groom.jpg  couple-01.jpg  couple-02.jpg  couple-03.jpg  pre-wedding.jpg
  family.jpg  ceremony.jpg  rings.jpg  temple.jpg  mandap.jpg  mehendi.jpg`.
  Next.js serves them as AVIF or WebP automatically. If a photo's shape changes a lot, update `width`/`height` in `src/content/photos.ts`.
- **Temple photos:** in `public/images/site/`, the files are `hero-tall.jpg`, `hero-wide.jpg`, `pillars.jpg` and `gopuram-dusk.jpg`.
- The current photos are temporary Unsplash images (see `ASSET-CREDITS.md`).

## Structure
```
src/app/                 layout (fonts, metadata), globals.css (colours, fonts), page
src/content/             wedding.ts (all text/data), photos.ts (photo manifest)
src/components/site/     Invitation (all sections), Events (cards), Countdown, Music,
                         Motion (scroll reveals, parallax, tilt), Ornament (SVG divider + kalash),
                         site.module.css (all styles)
src/lib/ambient.ts       synthesised music
```
Files in the older folders (`components/experience`, `components/scenes`, `three`, `journey`)
are empty placeholders left from the previous version and can be deleted, along with
`public/images/temple/`. The `three` and `gsap` packages are no longer used, so you can
remove them from `package.json` if you like.

## Accessibility
- Event cards, arrows and dots work by keyboard and touch. Links and buttons are at least 46 px tall.
- With `prefers-reduced-motion`, all animation, parallax, tilt and smooth scrolling is turned off and everything shows at once.
- If JavaScript is off, every section is still visible (the hidden "before" state only applies once motion is switched on).
