/**
 * The whole invitation as one clean, normally-scrolling page:
 *
 *   Hero (temple in daylight) → Invitation (arch card) → Bride & Groom →
 *   Our Story → Celebrations (event cards) → Moments (gallery) →
 *   Countdown → RSVP + Instagram → Thank-you footer
 *
 * Sharp photographs, solid colours, thin gold lines. Motion is added by
 * <Motion/> through data attributes:
 *   data-reveal="up|arch|flip-l|flip-r|tilt|zoom|rise|draw"  3D entrance when scrolled into view
 *   style={{"--d": n}}                                       stagger delay (×90 ms)
 *   data-parallax="0.15"                                     depth parallax while scrolling
 *   data-tilt                                                3D tilt that follows the pointer
 * All words live in src/content/wedding.ts.
 */
import Image from "next/image";
import type { CSSProperties } from "react";
import styles from "./site.module.css";
import { Divider, Kalash } from "./Ornament";
import Events from "./Events";
import Countdown from "./Countdown";
import Music from "./Music";
import Motion from "./Motion";
import { photos, type PhotoKey } from "@/content/photos";
import { wedding, telHref, whatsappHref } from "@/content/wedding";

const d = (n: number) => ({ "--d": n }) as CSSProperties;

function Photo({ k, sizes, className, priority }: { k: PhotoKey; sizes: string; className?: string; priority?: boolean }) {
  const p = photos[k];
  return <Image src={p.src} alt={p.alt} width={p.width} height={p.height} sizes={sizes} className={className} priority={priority} />;
}

function Heading({ kicker, title, light }: { kicker: string; title: string; light?: boolean }) {
  return (
    <header className={styles.heading} data-light={light || undefined}>
      <span data-reveal="rise" style={d(0)}>
        <Kalash className={styles.kalash} />
      </span>
      <p className={styles.kicker} data-reveal="up" style={d(1)}>
        {kicker}
      </p>
      <h2 className={styles.title} data-reveal="tilt" style={d(2)}>
        {title}
      </h2>
      <span data-reveal="draw" style={d(3)}>
        <Divider className={styles.divider} />
      </span>
    </header>
  );
}

/** Each letter turns up into place in 3D. Screen readers read the plain word. */
function Letters({ text, start }: { text: string; start: number }) {
  return (
    <span className={styles.word}>
      <span className="sr-only">{text}</span>
      {[...text].map((ch, i) => (
        <span key={i} className={styles.letter} style={d(start + i)} aria-hidden="true">
          {ch}
        </span>
      ))}
    </span>
  );
}

export default function Invitation() {
  const { bride, groom } = wedding;
  return (
    <>
      <Motion />
      <div className={styles.progress} aria-hidden="true" />

      {/* ── Hero ───────────────────────────────────────────── */}
      <section className={styles.hero} id="top">
        <div className={`${styles.heroMedia} ${styles.heroWide}`} data-parallax="0.25">
          <Image
            src="/images/site/hero-wide.jpg"
            alt="A South Indian temple under a bright sky"
            fill
            priority
            sizes="(min-width: 900px) 1px, 100vw"
            className={styles.heroImg}
          />
        </div>
        <div className={`${styles.heroPane} ${styles.heroTall}`}>
          <div className={styles.heroMedia} data-parallax="0.18">
            <Image
              src="/images/site/hero-tall.jpg"
              alt="A colourful South Indian temple tower"
              fill
              priority
              sizes="(min-width: 900px) 50vw, 1px"
              className={styles.heroImg}
            />
          </div>
        </div>
        <div className={styles.heroText} data-parallax="-0.12">
          <p className={styles.heroKicker}>The wedding of</p>
          <h1 className={styles.heroNames}>
            <Letters text={bride} start={2} />
            <em>weds</em>
            <Letters text={groom} start={2 + bride.length + 2} />
          </h1>
          <p className={styles.heroLine}>
            {wedding.entrance.together} {wedding.entrance.invite}
          </p>
        </div>
        <a href="#invite" className={styles.scrollCue} aria-label="Scroll to the invitation">
          <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
            <path d="M6 9l6 6 6-6" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </a>
      </section>

      {/* ── Invitation ─────────────────────────────────────── */}
      <section className={styles.invite} id="invite">
        <div className={styles.inviteMedia} data-parallax="0.2">
          <Image src="/images/site/pillars.jpg" alt="" fill sizes="100vw" className={styles.inviteBg} />
        </div>
        <div className={styles.archWrap} data-reveal="arch">
          <div className={styles.arch} data-tilt="4">
            <div className={styles.archInner}>
              <p className={styles.blessing} lang="sa" data-reveal="up" style={d(3)}>
                {wedding.invitation.blessing}
              </p>
              <span data-reveal="draw" style={d(4)}>
                <Divider className={styles.dividerSm} />
              </span>
              <p className={styles.inviteIntro} data-reveal="up" style={d(5)}>
                {wedding.invitation.intro}
              </p>
              <div className={styles.inviteNames}>
                <div data-reveal="tilt" style={d(6)}>
                  <h2>{bride}</h2>
                  {wedding.parents.bride && <p className={styles.parents}>daughter of {wedding.parents.bride}</p>}
                </div>
                <span className={styles.amp} data-reveal="zoom" style={d(7)}>
                  &amp;
                </span>
                <div data-reveal="tilt" style={d(8)}>
                  <h2>{groom}</h2>
                  {wedding.parents.groom && <p className={styles.parents}>son of {wedding.parents.groom}</p>}
                </div>
              </div>
              <p className={styles.inviteClosing} data-reveal="up" style={d(9)}>
                {wedding.invitation.closing}
              </p>
              <a href="#events" className={styles.textLink} data-reveal="up" style={d(10)}>
                See the celebrations
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── Bride & Groom ──────────────────────────────────── */}
      <section className={styles.section} id="couple">
        <Heading kicker="Meet" title="The Bride & Groom" />
        <div className={styles.couple}>
          {(["bride", "groom"] as const).map((who, i) => (
            <figure key={who} className={styles.person} data-reveal={who === "bride" ? "flip-l" : "flip-r"} style={d(i * 2)}>
              <div className={styles.portrait} data-tilt="8">
                <Photo k={who} sizes="(min-width: 760px) 340px, 44vw" />
              </div>
              <figcaption>
                <span className={styles.personLabel}>{wedding.couple[who].label}</span>
                <span className={styles.personName}>{who === "bride" ? bride : groom}</span>
                <span className={styles.personLine}>{wedding.couple[who].line}</span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* ── Our story ──────────────────────────────────────── */}
      <section className={`${styles.section} ${styles.paper}`} id="story">
        <Heading kicker="How it began" title="Our Story" />
        <ol className={styles.story}>
          {wedding.story.map((s, i) => (
            <li key={s.title} className={styles.storyItem}>
              <div className={styles.storyPhoto} data-reveal={i % 2 ? "flip-r" : "flip-l"}>
                <div className={styles.storyPhotoInner} data-tilt="6">
                  <Photo k={s.photo} sizes="(min-width: 760px) 460px, 92vw" />
                </div>
              </div>
              <div className={styles.storyText}>
                <span className={styles.storyNum} data-reveal="up" style={d(2)}>
                  0{i + 1}
                </span>
                <h3 data-reveal="tilt" style={d(3)}>
                  {s.title}
                </h3>
                <p data-reveal="up" style={d(4)}>
                  {s.text}
                </p>
              </div>
            </li>
          ))}
        </ol>
      </section>

      {/* ── Celebrations ───────────────────────────────────── */}
      <section className={`${styles.section} ${styles.maroon}`} id="events">
        <Heading kicker="Join us for" title="The Celebrations" light />
        <Events />
      </section>

      {/* ── Gallery ────────────────────────────────────────── */}
      <section className={styles.section} id="gallery">
        <Heading kicker="Moments" title="Held in the Light" />
        <div className={styles.gallery}>
          {(["couple-01", "ceremony", "couple-02", "rings", "pre-wedding", "mehendi"] as const).map((k, i) => (
            <div key={k} className={styles.galleryItem} data-k={k} data-reveal="zoom" style={d(i)}>
              <Photo k={k} sizes="(min-width: 900px) 30vw, 46vw" />
            </div>
          ))}
        </div>
      </section>

      {/* ── Countdown ──────────────────────────────────────── */}
      <section className={`${styles.section} ${styles.paper}`} id="countdown">
        <Heading kicker="The wedding day" title="Counting the Days" />
        <Countdown />
      </section>

      {/* ── RSVP + Instagram ───────────────────────────────── */}
      <section className={`${styles.section} ${styles.maroon}`} id="rsvp">
        <div className={styles.cards}>
          <div data-reveal="arch" style={d(0)}>
            <div className={styles.card} data-tilt="5">
              <span className={styles.float}>
                <Kalash className={styles.kalash} />
              </span>
              <h2 className={styles.cardTitle}>{wedding.rsvp.heading}</h2>
              <p className={styles.cardText}>{wedding.rsvp.line}</p>
              <a className={`${styles.button} ${styles.shine}`} href={whatsappHref} target="_blank" rel="noopener noreferrer">
                <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                  <path
                    fill="currentColor"
                    d="M12 2.2A9.7 9.7 0 0 0 3.6 16.8L2.3 21.7l5-1.3A9.7 9.7 0 1 0 12 2.2zm0 17.7c-1.5 0-3-.4-4.2-1.2l-.3-.2-3 .8.8-2.9-.2-.3A8 8 0 1 1 12 19.9zm4.4-6c-.2-.1-1.4-.7-1.7-.8-.2-.1-.4-.1-.5.1l-.8 1c-.1.2-.3.2-.5.1a6.6 6.6 0 0 1-3.3-2.9c-.2-.4.2-.4.7-1.3.1-.2 0-.3 0-.4l-.8-1.8c-.2-.5-.4-.4-.5-.4h-.5a.9.9 0 0 0-.6.3 2.7 2.7 0 0 0-.8 2c0 1.2.8 2.3 1 2.5.1.1 1.6 2.5 4 3.5 1.5.6 2 .7 2.8.6.5-.1 1.4-.6 1.6-1.1.2-.6.2-1 .1-1.1l-.4-.2z"
                  />
                </svg>
                RSVP on WhatsApp
              </a>
              <a className={styles.phone} href={telHref}>
                Call / WhatsApp: {wedding.rsvp.phone}
              </a>
            </div>
          </div>

          <div data-reveal="arch" style={d(2)}>
            <div className={styles.card} data-tilt="5">
              <span className={styles.float}>
                <Kalash className={styles.kalash} />
              </span>
              <h2 className={styles.cardTitle}>{wedding.instagram.heading}</h2>
              <p className={styles.handle}>{wedding.instagram.handle}</p>
              <a className={`${styles.button} ${styles.buttonOutline}`} href={wedding.instagram.url} target="_blank" rel="noopener noreferrer">
                <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
                  <g fill="none" stroke="currentColor" strokeWidth="1.7">
                    <rect x="3.5" y="3.5" width="17" height="17" rx="5" />
                    <circle cx="12" cy="12" r="4" />
                  </g>
                  <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" />
                </svg>
                Open Instagram
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* ── Thank you ──────────────────────────────────────── */}
      <footer className={styles.footer}>
        <div className={styles.footerMedia} data-parallax="0.22">
          <Image src="/images/site/gopuram-dusk.jpg" alt="A temple tower at dusk" fill sizes="100vw" className={styles.footerImg} />
        </div>
        <div className={styles.footerText}>
          <p className={styles.footerNames} data-reveal="tilt">
            {bride} <em>&amp;</em> {groom}
          </p>
          <p className={styles.footerLine} data-reveal="up" style={d(2)}>
            {wedding.final.line}
          </p>
          <p className={styles.footerThanks} data-reveal="up" style={d(3)}>
            {wedding.final.thanks}
          </p>
        </div>
      </footer>

      <Music />
    </>
  );
}
