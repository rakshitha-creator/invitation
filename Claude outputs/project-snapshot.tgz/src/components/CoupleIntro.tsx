// Obsolete file from the previous design — not used. Safe to delete.
export {};
