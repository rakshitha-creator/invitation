# Asset credits — Sita & Ram wedding invitation

The page uses **real photographs** from Unsplash (listed below), shown sharp and ungraded.
Ornaments, icons and music were made for this project in code. No third-party illustrations,
templates or 3D models are used. The layout is original; the reference site was used only as
a general idea of a bright, section-by-section invitation.

## Page photographs (`public/images/site/`)

All under the **Unsplash License** (free for commercial and non-commercial use, no permission
or fee needed, attribution appreciated but not required: https://unsplash.com/license).
Unsplash+ (paid) images were excluded. Files were only resized and lightly sharpened.

| File | What it shows | Photographer | Source URL |
| --- | --- | --- | --- |
| hero-tall.jpg (desktop hero) | Colourful South Indian temple tower | Jayanth Muppaneni | https://unsplash.com/photos/a-very-tall-colorful-building-with-a-clock-on-its-face-xdDzKAK8BLE |
| hero-wide.jpg (phone hero) | Brihadeeswara Temple, Thanjavur | Avin CP | https://unsplash.com/photos/a-very-large-building-with-a-very-tall-tower-dGu_b4S7DXM |
| pillars.jpg (behind the invitation) | Long line of carved pillars | Nakkeeran Raveendran | https://unsplash.com/photos/a-long-line-of-pillars-in-a-building-dxgIrClfpOc |
| gopuram-dusk.jpg (footer) | Gopuram at dusk under the stars | SIBY | https://unsplash.com/photos/hindu-temple-tower-under-starry-sky-QXIBCvvA_jc |

`public/images/temple/` holds photos from the previous version. The page no longer uses
them, so that folder can be deleted.

## Temporary placeholder photos (`public/images/wedding/`)

All are from Unsplash under the **Unsplash License**: free for commercial and non-commercial
use, no permission or fee needed, and attribution appreciated but not required
(https://unsplash.com/license). Unsplash+ (paid) images were excluded. The people shown are
not Sita and Ram. These photos are stand-ins only.

| File | Photographer | Source URL | Licence | Attribution required? |
| --- | --- | --- | --- | --- |
| bride.jpg | Sabesh Photography LTD | https://unsplash.com/photos/a-woman-in-a-white-and-red-sari-j7Ljsqhnwag | Unsplash License | No (credited here) |
| groom.jpg | Royal Photography | https://unsplash.com/photos/groom-in-traditional-indian-wedding-attire-mab4JkLEe80 | Unsplash License | No (credited here) |
| couple-01.jpg | Sabesh Photography LTD | https://unsplash.com/photos/a-bride-and-groom-in-traditional-indian-wedding-attire-OzyvCE9a60M | Unsplash License | No (credited here) |
| couple-02.jpg | Sabesh Photography LTD | https://unsplash.com/photos/bride-and-groom-in-traditional-indian-wedding-attire-z3rzhRweKB4 | Unsplash License | No (credited here) |
| couple-03.jpg | Sabesh Photography LTD | https://unsplash.com/photos/a-man-and-a-woman-standing-next-to-each-other-m0J-phz_lSo | Unsplash License | No (credited here) |
| pre-wedding.jpg | Sabesh Photography LTD | https://unsplash.com/photos/newlyweds-in-traditional-attire-resting-on-grass-XrbofN77emw | Unsplash License | No (credited here) |
| family.jpg | Sabesh Photography LTD | https://unsplash.com/photos/a-bride-and-groom-getting-ready-for-their-wedding-ceremony-oJof1JomJ3g | Unsplash License | No (credited here) |
| ceremony.jpg | Sabesh Photography LTD | https://unsplash.com/photos/couple-showered-with-flower-petals-during-traditional-indian-wedding-ceremony-v5sG5-zYthE | Unsplash License | No (credited here) |
| rings.jpg | Arun Prakash | https://unsplash.com/photos/jWjdetjUMjk | Unsplash License | No (credited here) |
| temple.jpg | SIBY | https://unsplash.com/photos/hindu-temple-tower-under-starry-sky-QXIBCvvA_jc | Unsplash License | No (credited here) |
| mandap.jpg | AMISH THAKKAR | https://unsplash.com/photos/wedding-ceremony-under-floral-canopy-7O422yG_b80 | Unsplash License | No (credited here) |
| mehendi.jpg | Sujeeth Potla | https://unsplash.com/photos/hands-adorned-with-henna-and-gold-jewelry-5EfVgcZYi3s | Unsplash License | No (credited here) |
| public/assets/og.jpg (share image) | derived from couple-02.jpg + text | — | Unsplash License | No |

## Made for this project (original)

| Asset | Where | Notes |
| --- | --- | --- |
| Gold divider and kalash ornaments | `src/components/site/Ornament.tsx` | SVG |
| WhatsApp, Instagram, play/pause and arrow icons | `src/components/site/*.tsx` | Simple hand-drawn SVG glyphs |
| Ambient temple music (drone, plucked notes, bell) | `src/lib/ambient.ts` | Synthesised with the Web Audio API. No recordings. |

## Libraries and fonts

| Asset | Licence | URL |
| --- | --- | --- |
| Next.js, React | MIT | https://nextjs.org · https://react.dev |
| Cormorant Garamond (@fontsource) | SIL Open Font License 1.1 | https://fontsource.org/fonts/cormorant-garamond |
| Manrope (@fontsource) | SIL Open Font License 1.1 | https://fontsource.org/fonts/manrope |
| Tiro Devanagari Sanskrit (@fontsource) | SIL Open Font License 1.1 | https://fontsource.org/fonts/tiro-devanagari-sanskrit |

WhatsApp and Instagram are trademarks of Meta. Their glyphs here are simple hand-drawn icons
used only to label links to those services.
